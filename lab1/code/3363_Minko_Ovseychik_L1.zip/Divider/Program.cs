﻿using System;

namespace Divider
{
    internal class DivideIt
    {
        static void Main(string[] args)
        {
            int i, j, k;
            string temp;
            try
            {
                Console.Write("Enter the first integer: ");
                temp = Console.ReadLine();
                i = int.Parse(temp);
                Console.Write("Enter the second integer: ");
                temp = Console.ReadLine();
                j = int.Parse(temp);
                k = i/j;
                Console.WriteLine("The result of division is: {0}", k);
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("Error: Division by zero");
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: Invalid input");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: unexpected error {0}", e.StackTrace);
            }
        }
    }
}

