enum AccountType 
{ 
    Checking, 
    Deposit 
}

