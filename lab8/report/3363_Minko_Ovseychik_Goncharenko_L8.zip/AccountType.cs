enum AccountType 
{ 
    Checking, 
    Deposit 
}

