
struct BankAccount 
{
    public long accNo;
    public decimal accBal;
    public AccountType accType;
}
