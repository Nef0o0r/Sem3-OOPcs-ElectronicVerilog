    USING SYSTEM;

    /// <SUMMARY>
    ///    CLASS TO CREATE AN UPPER CASE COPY OF A FILE
    /// </SUMMARY>
    PUBLIC CLASS COPYFILEUPPER
    {
		PUBLIC STATIC VOID MAIN()
		{
			
		}       
    }
