﻿using System;
using System.Collections.Specialized;
using System.Runtime.Intrinsics.X86;
enum AccountType
{
    Checking,
    Deposit
}
class BankAccount
{
    private long accNo;
    private decimal accBal;
    private AccountType accType;

    private static long nextNumber = 123;

    public void Populate(decimal balance)
    {
        accNo = NextNumber();
        accBal = balance;
        accType = AccountType.Checking;
    }

    public bool Withdraw(decimal amount)
    {
        bool sufficientFunds = accBal >= amount;
        if (sufficientFunds)
        {
            accBal -= amount;
        }
        return sufficientFunds;
    }
    public decimal Deposit(decimal amount)
    {
        accBal += amount;
        return accBal;
    }
    public void TransferFrom(BankAccount accForm, decimal amount)
    {
        if (accForm.Withdraw(amount) == true)
        {
            Deposit(amount);
        }
    }
    //b1.Transfer(b2, 100)
    public long Number()
    {
        return accNo;
    }

    public decimal Balance()
    {
        return accBal;
    }

    public string Type()
    {
        return accType.ToString();
    }

    private static long NextNumber()
    {
        return nextNumber++;
    }
    public class Test
    {
        public static void Main()
        {
            BankAccount b1 = new BankAccount();
            BankAccount b2 = new BankAccount();
            b1.Populate(100);
            b2.Populate(100);
            Console.WriteLine("Счета до операций:");
            Console.WriteLine("b1 - Тип:{0}, Номер: {1}, Баланс: {2}", b1.Type(), b1.Number(), b1.Balance());
            Console.WriteLine("b2 - Тип:{0}, Номер: {1}, Баланс: {2}", b2.Type(), b2.Number(), b2.Balance());
            b1.TransferFrom(b2, 10);
            Console.WriteLine("Счета после операций:");
            Console.WriteLine("b1 - Тип:{0}, Номер: {1}, Баланс: {2}", b1.Type(), b1.Number(), b1.Balance());
            Console.WriteLine("b2 - Тип:{0}, Номер: {1}, Баланс: {2}", b2.Type(), b2.Number(), b2.Balance());


        }
    }
}