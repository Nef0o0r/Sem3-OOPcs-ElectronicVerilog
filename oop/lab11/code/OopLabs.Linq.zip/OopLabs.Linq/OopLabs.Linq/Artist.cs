﻿using System;

public class Artist
{
	public Artist()
	{
	}
}
