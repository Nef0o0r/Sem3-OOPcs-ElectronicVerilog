﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pattern2
{
    class Simulator : IEnumerable
    {
        private string[] weatherData =
        {
        "Температура: 25°C, Влажность: 60%, Давление: 1013 hPa",
        "Температура: 27°C, Влажность: 55%, Давление: 1010 hPa",
        "Температура: 22°C, Влажность: 70%, Давление: 1020 hPa"
    };

        public IEnumerator GetEnumerator()
        {
            foreach (string data in weatherData)
                yield return data;
        }
    }
}
