﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pattern2
{
    // Класс субъекта
    class WeatherStation
    {
        public delegate void WeatherUpdate(string data);
        public event WeatherUpdate Notify;

        private Simulator simulator = new Simulator();

        private const int updateInterval = 2000; // Интервал обновления в миллисекундах
        public void Start()
        {
            new Thread(Run).Start();
        }

        private void Run()
        {
            foreach (var data in simulator)
            {
                Console.WriteLine($"Станция сообщает: {data}");
                Notify?.Invoke(data.ToString());
                Thread.Sleep(updateInterval);
            }
        }
    }
}
