﻿using Pattern2;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

// Главный метод
class Program
{
    public static void Main(string[] args)
    {
        WeatherStation station = new WeatherStation();

        WeatherObserver observer1 = new WeatherObserver(station, "Наблюдатель 1");
        WeatherObserver observer2 = new WeatherObserver(station, "Наблюдатель 2");
        WeatherObserver observer3 = new WeatherObserver(station, "Наблюдатель 3");

        station.Start();

        Console.ReadLine();
    }
}

