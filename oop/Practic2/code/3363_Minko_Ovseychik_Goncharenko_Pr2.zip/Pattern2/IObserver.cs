﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pattern2
{
    // Интерфейс наблюдателя
    interface IObserver
    {
        void Update(string weatherData);
    }
}
