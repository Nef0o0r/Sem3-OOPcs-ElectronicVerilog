﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pattern2
{
    // Класс Наблюдателя
    class WeatherObserver : IObserver
    {
        private string name;
        private WeatherStation station;

        public WeatherObserver(WeatherStation station, string name)
        {
            this.station = station;
            this.name = name;
            station.Notify += Update;
        }

        public void Update(string weatherData)
        {
            Console.WriteLine($"{name} получил обновление: {weatherData}");
        }
    }
}
