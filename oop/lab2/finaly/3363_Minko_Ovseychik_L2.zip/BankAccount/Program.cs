﻿namespace BankAccount;

enum AccountType{Checking, Deposit};

internal class TypeDefiner
{
    static void Main(string[] args)
    {
        AccountType goldAccount = AccountType.Checking;
        AccountType platinumAccount = AccountType.Deposit;
        Console.WriteLine("The gold account is {0}", goldAccount);
        Console.WriteLine("The platinum account is {0}", platinumAccount);
    }
}


