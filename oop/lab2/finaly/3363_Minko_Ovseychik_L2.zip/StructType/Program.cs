﻿namespace StructType;

public enum AccountType{Checking, Deposit};

public struct BankAccount
{
    public long accNo;
    public decimal accBal;
    public AccountType accType;
}

class AccountInfo
{
    static void Main(string[] args)
    {
        BankAccount goldAccount;
        goldAccount.accNo = 12345678912345;
        goldAccount.accBal = 2750;
        goldAccount.accType = AccountType.Checking;
        Console.WriteLine("Account info:\n" +
                 "Id: {0}\nBalance: {1}\nType: {2}",
                 goldAccount.accNo, goldAccount.accBal, 
                 goldAccount.accType);
    }
}
